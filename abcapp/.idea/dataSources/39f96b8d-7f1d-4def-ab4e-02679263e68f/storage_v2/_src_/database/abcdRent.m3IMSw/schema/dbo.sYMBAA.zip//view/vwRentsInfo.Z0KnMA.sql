CREATE VIEW [dbo].[vwRentsInfo]
AS
    SELECT
        EMAIL                                                        AS [Email],
        CARID                                                        AS [Car ID],
        RENTSTARTDATE                                                AS [Start Date],
        RENTENDDATE                                                  AS [End Date],
        ISRETURNED                                                   AS [Returned ?],
        COALESCE(CONVERT(VARCHAR(10), RETURNEDDATE), 'not returned') AS [Returned Date],
        AMOUNT
    FROM
        CUSTOMER    c
        INNER JOIN
            CARRENTAL cr
                ON c.CUSTOMERID = cr.CUSTOMERID;
go

