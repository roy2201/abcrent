


CREATE procedure [dbo].[spRentedBetween]
	@date1		date,
	@date2		date
as
begin

    IF @date1 > @date2
    BEGIN
        DECLARE @tempDate DATE;

        -- Swap @date1 and @date2
        SET @tempDate = @date1;
        SET @date1 = @date2;
        SET @date2 = @tempDate;
    END


	select * from vwRentsInfo
	where RENTSTARTDATE between @date1 and @date2

end
go

