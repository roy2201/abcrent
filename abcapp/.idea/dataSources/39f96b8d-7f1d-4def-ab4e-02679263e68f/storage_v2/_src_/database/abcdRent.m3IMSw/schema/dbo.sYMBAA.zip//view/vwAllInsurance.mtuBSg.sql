CREATE view [dbo].[vwAllInsurance]
as
    select
        INSURANCEID           as [ID],
        CARID                 as [Car ID],
        INSURANCEPROVIDER     as [Provider],
        INSURANCEPOLICYNUMBER as [Policy Number],
        EXPIRYDATE            as [Expired In],
        COST                  as [Ins Cost]
    from
        INSURANCE
go

