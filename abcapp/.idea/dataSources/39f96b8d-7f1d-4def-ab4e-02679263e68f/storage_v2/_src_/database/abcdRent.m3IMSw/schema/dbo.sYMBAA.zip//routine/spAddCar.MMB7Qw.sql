CREATE PROCEDURE [dbo].[spAddCar] 
	@licensePlate	varchar(20),
	@color			varchar(256),
	@make			varchar(256),
	@model			varchar(256),
	@type			varchar(256),
	@mileage		int
AS
BEGIN

  INSERT INTO CAR
    VALUES (@licensePlate, @color, @make, @model, @type, @mileage, 0)

END
go

