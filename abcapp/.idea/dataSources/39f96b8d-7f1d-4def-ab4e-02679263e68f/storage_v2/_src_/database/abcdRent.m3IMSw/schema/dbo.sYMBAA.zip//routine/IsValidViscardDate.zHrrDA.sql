
CREATE FUNCTION [dbo].[IsValidViscardDate] (@inputDate DATE)
RETURNS BIT
AS
BEGIN
    DECLARE @isValid BIT;

    SET @isValid = CASE
                        WHEN @inputDate IS NULL THEN 0 -- Invalid: Date is NULL
                        WHEN TRY_CAST(@inputDate AS DATE) IS NULL THEN 0 -- Invalid: Not a valid date
                        ELSE 1 -- Valid
                   END;

    RETURN @isValid;
END;
go

