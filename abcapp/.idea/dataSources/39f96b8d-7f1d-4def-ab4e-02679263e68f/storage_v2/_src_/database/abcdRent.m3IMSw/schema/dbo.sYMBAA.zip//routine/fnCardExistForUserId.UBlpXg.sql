CREATE function [dbo].[fnCardExistForUserId] (
    @cid int,
    @cardNumber varchar(16))
returns bit
as
begin
    declare @haveCard bit
    select @haveCard = Case
                            when exists (   select 1
                                              from VISACARD
                                             where CUSTOMERID = @cid
                                               and CardNumber = @cardNumber) then 1
                            else 0 end
    return @haveCard
end
go

