CREATE VIEW [dbo].[vwRefundRequests]
AS
    SELECT
        REQUESTID	AS [Request ID],
        RR.RENTALID AS [Rent ID],
        [STATUS]	AS [Request Status],
        RESOLUTION	AS [Resolution],
        COALESCE(CONVERT(VARCHAR(10), ACCEPTEDDATE, 101), 'N/A') AS [Accepted Date]
    FROM
        REFUNDREQUESTS RR;
go

