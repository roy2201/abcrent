CREATE PROCEDURE [dbo].[spAddVisa] @cid            INT,
                                  @cardHoldreName VARCHAR(256),
                                  @expDate        DATE,
                                  @CVV            VARCHAR(3),
                                  @cardNumber     VARCHAR(5),
                                  @ErrorCode      INT OUTPUT
AS
  BEGIN
      IF NOT EXISTS (SELECT 1
                     FROM   customer
                     WHERE  customerid = @cid)
        --should add card to existing customer
        BEGIN
            PRINT 'CUSTOMER DOES NOT EXIST'

            SET @ErrorCode = 1

            RETURN;
        END

      IF Datediff(day, Getdate(), @EXPDATE) < 0 --exp date validation
        BEGIN
            SET @ErrorCode = 2

            PRINT 'INVALID EXPIRY DATE'

            RETURN;
        END

      INSERT INTO visacard
                  (customerid,
                   cardholdername,
                   cvv,
                   expirationdate,
                   balance,
                   cardnumber)
      VALUES      (@cid,
                   @cardHoldreName,
                   @CVV,
                   @expDate,
                   1000,
                   @cardNumber);

      SET @ErrorCode = 0

      PRINT 'CARD ADDED'
  END;
go

