CREATE view [dbo].[vwCarInfoWithPrice]
as
	select c.*,cp.PRICEPERDAY
	from vwAllCars as c
	INNER JOIN 
	CARPRICING as cp On c.[Car ID] = cp.CARID
go

