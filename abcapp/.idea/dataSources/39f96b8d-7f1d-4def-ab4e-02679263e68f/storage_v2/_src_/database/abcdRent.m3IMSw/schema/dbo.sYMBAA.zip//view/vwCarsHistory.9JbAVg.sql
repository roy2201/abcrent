


CREATE VIEW [dbo].[vwCarsHistory]
AS
	SELECT  INOUTID   AS [ID],
			CARID	  AS [Car ID],
			ENTRYTIME AS [Entry Time],
			EXITTIME  AS [Exit Time]
	FROM CARINOUT
go

