create view vwLoggedUsers
as
	select EMAIL as [Email]
	from CUSTOMER
	where ISLOGGED=1
go

