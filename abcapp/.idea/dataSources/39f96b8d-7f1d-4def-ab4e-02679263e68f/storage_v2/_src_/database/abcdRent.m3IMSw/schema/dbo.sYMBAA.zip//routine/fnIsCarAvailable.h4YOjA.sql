CREATE FUNCTION [dbo].[fnIsCarAvailable] (@CarID INT)
RETURNS BIT
AS
BEGIN
    DECLARE @available BIT;

    SELECT TOP 1 @available = isRented
      FROM CAR
     WHERE CARID = @CarID;

    RETURN COALESCE(@available, 0);
END;
go

