
CREATE view [dbo].[vwExpiredInsurance]
as
	select *
	from vwAllInsurance
	where (datediff(day,getdate(),[Expired In])) < 0
go

