
CREATE PROCEDURE [dbo].[spConfirmArrival]
    @carid      INT,
    @newMileage INT,
	@ErrorCode	INT OUTPUT
AS
BEGIN
	
	IF EXISTS (SELECT 1 FROM CAR WHERE CARID = @carid AND ISRENTED = 1)
	BEGIN

		UPDATE CAR
		SET MILEAGE = MILEAGE + @newMileage
		WHERE CARID = @carid

		UPDATE CARRENTAL
		SET RETURNEDDATE = GETDATE(),
			ISRETURNED   = 1
		WHERE CARID = @carid

		UPDATE CAR
		SET ISRENTED = 0
		WHERE CARID = @carid

		SET @ErrorCode = 0 --succes

	END
	ELSE
	BEGIN
		SET @ErrorCode = 1 --car not rented
	END
END;
go

