
CREATE PROCEDURE [dbo].[spRenewInsurance]
    @CarID INT,
    @ErrorCode INT OUTPUT
AS
BEGIN
    DECLARE @CurrentExpiryDate DATE
    DECLARE @CurrentDate DATE = GETDATE()
    DECLARE @NewStartingDate DATE
    DECLARE @NewExpiryDate DATE

    -- Initialize error code to 0 (no error)
    SET @ErrorCode = 0

    -- Get the current expiry date
    SELECT @CurrentExpiryDate = MAX(EXPIRYDATE)
    FROM INSURANCE
    WHERE CARID = @CarID

    -- Check if the current expiry date is not null and is in the past
    IF @CurrentExpiryDate IS NOT NULL AND @CurrentExpiryDate <= @CurrentDate
    BEGIN
        -- Calculate new starting date and expiry date for renewal (assuming 3 days duration)
        SET @NewStartingDate = DATEADD(DAY, 1,GETDATE())
        SET @NewExpiryDate = DATEADD(DAY, 3, @NewStartingDate)

        -- Insert a new insurance row for the car with the same values
        INSERT INTO INSURANCE (CARID, INSURANCEPROVIDER, INSURANCEPOLICYNUMBER, STARTINGDATE, EXPIRYDATE, COST)
        SELECT CARID, INSURANCEPROVIDER, INSURANCEPOLICYNUMBER, @NewStartingDate, @NewExpiryDate, COST
        FROM INSURANCE
        WHERE CARID = @CarID AND EXPIRYDATE = @CurrentExpiryDate

        PRINT 'New insurance inserted successfully.'
    END
    ELSE
    BEGIN
        -- Set error code to 2 (insurance not expired)
        SET @ErrorCode = 1
        PRINT 'Error: Unable to insert new insurance. The insurance is not expired.'
    END
END
go

