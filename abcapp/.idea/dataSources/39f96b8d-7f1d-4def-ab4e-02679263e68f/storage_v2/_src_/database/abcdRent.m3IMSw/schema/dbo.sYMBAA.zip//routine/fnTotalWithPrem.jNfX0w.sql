CREATE FUNCTION [dbo].[fnTotalWithPrem] (
    @CarId INT,
    @NumDays INT,
    @UserID INT)
RETURNS FLOAT
AS
BEGIN
    DECLARE @DailyRate FLOAT;
    DECLARE @TotalAmount FLOAT;
    DECLARE @IsPremium BIT;

    SET @IsPremium = dbo.fnCheckPrem(@UserID);

    SELECT @DailyRate = PRICEPERDAY
      FROM vwCarInfoWithPrice
     WHERE [Car ID] = @CarId;

    IF @IsPremium = 1
    BEGIN
        SET @DailyRate = @DailyRate * 0.85; -- Apply a 15% discount
    END

    SET @TotalAmount = @DailyRate * @NumDays;

    RETURN @TotalAmount;
END
go

