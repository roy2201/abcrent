CREATE PROCEDURE [dbo].[spViewMatches]
	@type VARCHAR(256),
	@make VARCHAR(256)
AS
BEGIN
    IF @type = 'any' AND @make = 'any'
    BEGIN
        SELECT *
        FROM vwCarInfoWithPrice
    END
    ELSE IF @type = 'any'
    BEGIN
        SELECT *
        FROM vwCarInfoWithPrice as v
        WHERE v.Make = @make
    END
    ELSE IF @make = 'any'
    BEGIN
        SELECT *
        FROM vwCarInfoWithPrice
        WHERE [TYPE] = @type
    END
    ELSE
    BEGIN
        SELECT *
        FROM vwCarInfoWithPrice
        WHERE [TYPE] = @type AND Make = @make
    END
END
go

