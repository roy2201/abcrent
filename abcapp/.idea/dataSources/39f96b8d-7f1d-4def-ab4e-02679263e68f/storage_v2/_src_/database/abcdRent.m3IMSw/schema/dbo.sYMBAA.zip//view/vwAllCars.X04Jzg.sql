CREATE VIEW [dbo].[vwAllCars]
AS
  SELECT carid        AS [Car ID],
         licenseplate AS [License Plate],
         color        AS [Color],
         model        AS [Model],
         [type]       AS [Type],
		 MANUFACTURER as [Make],
         mileage      AS [Mileage],
         CASE
            WHEN isrented = 1 THEN 'Rented'
            WHEN isrented = 0 THEN 'Available'
            ELSE 'Unknown'
         END AS [Rented/Availability]
  FROM   car;

go

