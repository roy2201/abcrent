CREATE PROCEDURE [dbo].[spSignOut]
    @CustomerId INT
AS
BEGIN
    UPDATE CUSTOMER
    SET ISLOGGED = 0
    WHERE CUSTOMERID = @CustomerId;
END;
go

