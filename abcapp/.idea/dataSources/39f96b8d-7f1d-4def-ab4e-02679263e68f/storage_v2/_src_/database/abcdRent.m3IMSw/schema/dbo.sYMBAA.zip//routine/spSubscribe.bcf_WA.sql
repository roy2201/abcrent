CREATE PROCEDURE spSubscribe
	@CID			INT
AS
BEGIN

	DECLARE @Today		DATE,
			@EndDate	DATE

	SET @Today   = GETDATE()
	SET @EndDate = DATEADD(DAY, 3, @Today)

	INSERT INTO SUBSCRIPTION
	VALUES
	(@CID, @Today, @EndDate, 0)

END

go

