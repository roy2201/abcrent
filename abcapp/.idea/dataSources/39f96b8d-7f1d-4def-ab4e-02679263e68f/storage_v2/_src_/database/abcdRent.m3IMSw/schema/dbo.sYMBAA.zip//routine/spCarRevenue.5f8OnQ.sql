
CREATE procedure [dbo].[spCarRevenue]
	@greaterthan	float,
	@lessthan		float
as
begin
	
	if @lessthan is null
	begin
		select RI.*
		from vwRentsInfo RI
		where ri.[Car ID] in (
			select [Car ID]
			from vwRentsInfo as ri
			group by [Car ID]
			Having Sum(Amount) > @greaterthan )
	end

	else if @greaterthan is null
	begin
		select RI.*
		from vwRentsInfo RI
		where [Car ID] in (
			select [Car ID]
			from vwRentsInfo
			group by [Car ID]
			Having Sum(Amount) < @lessthan )
	end

	else
	begin
		select RI.*
		from vwRentsInfo RI
		where [Car ID] in (
			select [Car ID]
			from vwRentsInfo
			group by [Car ID]
			Having Sum(Amount) > @greaterthan and Sum(Amount) < @lessthan)
	end

end
go

