CREATE PROCEDURE spChangePassword
	@NewPassword		VARCHAR(256),
	@CID				INT,
	@ErrorCode			INT		OUTPUT
AS
BEGIN
	
	SET NOCOUNT ON

	BEGIN TRY

		--CHECK IF THE USER EXISTS
		IF EXISTS (SELECT 1 FROM CUSTOMER WHERE CUSTOMERID = @CID)
		BEGIN

			DECLARE @HashedPassword	VARCHAR(256);
			SET @HashedPassword = CONVERT(VARCHAR(256), HASHBYTES('SHA2_256', @NewPassword), 2);

			UPDATE CUSTOMER
			SET PASSWORDHASH = @HashedPassword
			WHERE CUSTOMERID = @CID

			SET @ErrorCode = 0 --SUCCESS
		END
		ELSE
		BEGIN

			SET @ErrorCode = 1 --FAIL
			PRINT 'User with UserID ' + CAST(@CID AS VARCHAR(10)) + ' does not exist. Password change failed.';
		END
	END TRY
	BEGIN CATCH

		SET @ErrorCode = 2
		PRINT 'Error during password change: ' + ERROR_MESSAGE();
    END CATCH
END
go

