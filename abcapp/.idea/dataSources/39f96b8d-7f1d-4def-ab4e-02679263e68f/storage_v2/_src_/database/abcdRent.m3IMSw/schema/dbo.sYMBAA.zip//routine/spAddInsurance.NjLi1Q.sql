CREATE PROCEDURE [dbo].[Spaddinsurance] @CARID                 INT,
                                       @INSURANCEPROVIDER     VARCHAR(256),
                                       @INSURANCEPOLICYNUMBER VARCHAR(20),
                                       @STARTINGDATE          DATE,
                                       @EXPIRYDATE            DATE
AS
  BEGIN
      INSERT INTO [dbo].[insurance]
                  ([carid],
                   [insuranceprovider],
                   [insurancepolicynumber],
                   [startingdate],
                   [expirydate],
                   [cost])
      VALUES      (@CARID,
                   @INSURANCEPROVIDER,
                   @INSURANCEPOLICYNUMBER,
                   @STARTINGDATE,
                   @EXPIRYDATE,
                   1000);
  END; 
go

