CREATE PROCEDURE [dbo].[spSignUp]
    @FirstName	VARCHAR(256),
    @LastName	VARCHAR(256),
    @Age		INT,
    @Address	VARCHAR(256),
    @Email		VARCHAR(256),
    @Password	VARCHAR(256),
    @ErrorCode	INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        -- Check if the email already exists
        IF NOT EXISTS (SELECT 1 FROM CUSTOMER WHERE EMAIL = @Email)
        BEGIN
            DECLARE @HashedPassword VARCHAR(256);
            SET @HashedPassword = CONVERT(VARCHAR(256), HASHBYTES('SHA2_256', @Password), 2);
            -- PRINT 'Hashed password is: ' + @HashedPassword;

            -- Insert new customer
            INSERT INTO CUSTOMER (FIRSTNAME, LASTNAME, AGE, [ADDRESS], EMAIL, [PASSWORDHASH], ISLOGGED)
            VALUES (@FirstName, @LastName, @Age, @Address, @Email, @HashedPassword, 0);

            SET @ErrorCode = 0;
            -- PRINT 'ErrorCode : ' + CAST(@ErrorCode AS VARCHAR(1));
            PRINT 'Sign up successful for ' + @FirstName + ' ' + @LastName;
        END
        ELSE
        BEGIN
            -- Email already exists, handle accordingly (e.g., raise an error or set an output parameter)
            SET @ErrorCode = 1;
            -- PRINT 'ErrorCode : ' + CAST(@ErrorCode AS VARCHAR(1));
            PRINT 'Email already exists. Sign up failed.';
        END
    END TRY
    BEGIN CATCH
        -- Handle the error (you can log or raise an error as needed)
        SET @ErrorCode = 2;
        -- PRINT 'ErrorCode : ' + CAST(@ErrorCode AS VARCHAR(1));
        PRINT 'Error during sign up: ' + ERROR_MESSAGE();
    END CATCH
END;
go

