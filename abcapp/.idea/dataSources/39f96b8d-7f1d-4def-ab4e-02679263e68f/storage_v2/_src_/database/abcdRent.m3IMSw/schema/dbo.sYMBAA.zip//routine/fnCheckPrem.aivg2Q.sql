CREATE FUNCTION [dbo].[fnCheckPrem] (@CustomerID INT)
RETURNS BIT
AS
BEGIN
    DECLARE @isPremium BIT

    SELECT @isPremium = CASE
                             WHEN EXISTS (SELECT 1 FROM SUBSCRIPTION WHERE CUSTOMERID = @CustomerID) THEN 1
                             ELSE 0 END

    RETURN @isPremium
END
go

