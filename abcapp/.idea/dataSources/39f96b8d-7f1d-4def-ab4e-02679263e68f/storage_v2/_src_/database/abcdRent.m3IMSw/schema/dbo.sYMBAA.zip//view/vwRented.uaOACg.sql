
CREATE view [dbo].[vwRented]
as
	select * 
	from   vwAllCars
	where  [Rented/Availability] = 'Rented'
go

