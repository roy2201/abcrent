CREATE PROCEDURE spDeleteCar @carid INT
AS
  BEGIN
      -- remove car in out
      DELETE FROM carinout
      WHERE  carid = @carid

      -- remove car insurance
      DELETE FROM insurance
      WHERE  carid = @carid

      -- remove car pricing
      DELETE FROM carpricing
      WHERE  carid = @carid

      -- remove from rentals
      DELETE FROM carrental
      WHERE  carid = @carid

      -- remove car from table car
      DELETE FROM car
      WHERE  carid = @carid
  END 

  --shouldn't we delete the refund reequest assocaited to this rent of the car ? 
  --discuss
go

