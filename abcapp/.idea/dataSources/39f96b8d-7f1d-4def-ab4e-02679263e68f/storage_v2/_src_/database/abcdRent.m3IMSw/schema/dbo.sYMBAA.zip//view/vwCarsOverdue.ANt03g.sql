CREATE VIEW [dbo].[vwCarsOverdue]
AS
  SELECT vc.*,
         rentstartdate AS [Start Date],
         rentenddate   AS [End Date]
  
  FROM   vwallcars vc
         INNER JOIN carrental cr
		 ON vc.[car id] = cr.carid
		 AND DATEDIFF(DAY,GETDATE(),CR.RENTENDDATE) < 0
go

