

CREATE VIEW [dbo].[vwCarsOverdue]
AS
  SELECT vc.*,
         cr.rentstartdate AS [Start Date],
         cr.rentenddate   AS [End Date]
  FROM   vwallcars vc
         INNER JOIN carrental cr
		 ON vc.[car id] = cr.carid
		 AND cr.rentenddate < GETDATE()
		 And [Rented/Availability] = 'Rented'
go

