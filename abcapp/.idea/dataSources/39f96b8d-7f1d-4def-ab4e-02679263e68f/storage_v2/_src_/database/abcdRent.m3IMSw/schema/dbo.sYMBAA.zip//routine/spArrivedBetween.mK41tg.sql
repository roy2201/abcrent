CREATE PROCEDURE [dbo].[spArrivedBetween]
    @date1      DATE,
    @date2      DATE
AS
BEGIN
    -- Check if @date1 is greater than @date2, swap them if necessary
    IF @date1 > @date2
    BEGIN
        DECLARE @tempDate DATE;

        -- Swap @date1 and @date2
        SET @tempDate = @date1;
        SET @date1 = @date2;
        SET @date2 = @tempDate;
    END

    -- Select data based on the corrected date range
    SELECT *
    FROM vwRentsInfo as ri
    WHERE ri.[Returned Date] BETWEEN @date1 AND @date2;
END;
go

