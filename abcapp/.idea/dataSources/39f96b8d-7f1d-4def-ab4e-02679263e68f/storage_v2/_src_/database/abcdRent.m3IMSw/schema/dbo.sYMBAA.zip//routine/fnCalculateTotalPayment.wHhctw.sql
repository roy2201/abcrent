CREATE FUNCTION [dbo].[fnCalculateTotalPayment] (
    @CarId INT,
    @NumDays INT)
RETURNS FLOAT
AS
BEGIN
    DECLARE @DailyRate FLOAT;
    DECLARE @TotalAmount FLOAT;
    
	SELECT @DailyRate = PRICEPERDAY
    FROM vwCarInfoWithPrice
    WHERE [Car ID] = @CarId;
    
	SET @TotalAmount = @DailyRate * @NumDays;
    RETURN @TotalAmount;
END
go

