CREATE FUNCTION [dbo].[fnCheckBalance] (@CardNumber VARCHAR(16))
RETURNS BIT
AS
BEGIN
    DECLARE @IsEnoughBalance BIT;

    SELECT @IsEnoughBalance = CASE
                                   WHEN Balance >= 0 THEN 1
                                   ELSE 0 END
      FROM VISACARD
     WHERE CardNumber = @CardNumber;

    RETURN @IsEnoughBalance;
END;
go

