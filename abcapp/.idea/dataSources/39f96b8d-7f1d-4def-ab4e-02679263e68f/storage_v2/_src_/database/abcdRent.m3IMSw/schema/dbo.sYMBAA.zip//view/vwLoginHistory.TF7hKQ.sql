CREATE VIEW [dbo].[vwLoginHistory]
AS
SELECT 
    C.EMAIL AS [Email],
    SESSIONDURATION AS [Session Duration],
    FORMAT(LOGINTIME, 'yyyy-MM-dd HH:mm') AS [Login Time],
	FORMAT(LOGOUTTIME, 'yyyy-MM-dd HH:mm') AS [Logout Time]
FROM 
    LOGINHISTORY LH
	INNER JOIN CUSTOMER C
	ON C.CUSTOMERID = LH.CUSTOMERID 
go

