CREATE view [dbo].[vwPendingRequests]
as
	SELECT *
	FROM  vwRefundRequests
	WHERE [Request Status] = 'PENDING' and RESOLUTION = 'NOT REFUNDED'
go

