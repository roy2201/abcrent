CREATE PROCEDURE [dbo].[spSignIn]
    @Email      VARCHAR(256),
    @Password   VARCHAR(256),
    @ErrorCode  INT OUTPUT,
    @UserId     INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    -- Check if the email exists
    IF EXISTS (SELECT 1 FROM CUSTOMER WHERE EMAIL = @Email)
    BEGIN

        DECLARE @HashedPassword VARCHAR(256);
        SELECT @HashedPassword = [PASSWORDHASH] FROM CUSTOMER WHERE EMAIL = @Email;

        -- Check if the hashed password matches
        IF @HashedPassword = CONVERT(VARCHAR(256), HASHBYTES('SHA2_256', @Password), 2)
        BEGIN
            -- Password is correct, sign in successful
            SET @ErrorCode = 0;
            PRINT 'ErrorCode : ' + CAST(@ErrorCode AS VARCHAR(1));
            PRINT 'Sign in successful for ' + @Email;

            -- Return userId, for Java metadata
            SET @UserId = (SELECT DISTINCT CUSTOMERID FROM CUSTOMER WHERE EMAIL = @Email);

            -- Set ISLOGGED = 1 in the CUSTOMER table
            UPDATE CUSTOMER
            SET ISLOGGED = 1
            WHERE EMAIL = @Email;
        END
        ELSE
        BEGIN
            -- Password does not match
            SET @ErrorCode = 2;
            PRINT 'ErrorCode : ' + CAST(@ErrorCode AS VARCHAR(1));
            PRINT 'Incorrect password. Sign in failed.';
        END
    END
    ELSE
    BEGIN
        -- Email does not exist
        SET @ErrorCode = 1;
        PRINT 'ErrorCode : ' + CAST(@ErrorCode AS VARCHAR(1));
        PRINT 'Email not found. Sign in failed.';
    END
END;
go

